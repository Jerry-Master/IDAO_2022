export PATH=/usr/conda/bin:$PATH
python KNN.py
